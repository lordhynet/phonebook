﻿using Microsoft.EntityFrameworkCore;
using PhonebookTask.Data;
using PhonebookTask.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhonebookTask.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly PhonebookContext _context;

        public UserRepository(PhonebookContext context)
        {
            _context = context;
        }

        public async Task<bool> CreateContact(User user)
        {
           await _context.users.AddAsync(user);
            await _context.SaveChangesAsync();  
            return true;
        }

        public async Task<bool> DeleteContact(int id)
        {
            var user = await _context.users.FindAsync(id);
            if(user == null)
            {
                return false;
            }
               _context.users.Remove(user);
               await _context.SaveChangesAsync();
           
            return true;
        }

        public async Task<List<User>> GetContacts()
        {
            return await _context.users.ToListAsync();
        }
    }
}

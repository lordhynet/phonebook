﻿using PhonebookTask.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PhonebookTask.Repository
{
    public interface IUserRepository 
    {
        Task<bool> CreateContact(User user);
        Task<List<User>> GetContacts();
        Task <bool> DeleteContact (int id);
    }
}

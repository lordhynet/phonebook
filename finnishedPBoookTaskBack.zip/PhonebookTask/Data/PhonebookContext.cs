﻿using Microsoft.EntityFrameworkCore;
using PhonebookTask.Entities;

namespace PhonebookTask.Data
{
    public class PhonebookContext : DbContext
    {
        public PhonebookContext( DbContextOptions <PhonebookContext>options) : base(options)
        {
        }
        public DbSet<User> users { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace PhonebookTask.Controllers
{
    public class UserDTO
    {
        [Required]
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        [Required]
        public string Phonenumber { get; set; }
    }
}
﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PhonebookTask.Entities;
using PhonebookTask.Repository;
using System.Threading.Tasks;

namespace PhonebookTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly IUserRepository _repository;

        public ContactController(IUserRepository repository)
        {
            _repository = repository;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllContact()
        {
            var contact = await _repository.GetContacts();
            if (contact == null)
            {
                return NotFound();
            }
            return Ok(contact);
        }
        [HttpPost]
        public async Task<IActionResult> AddContact([FromBody] UserDTO userDto)
        {
            var user = new User()
            {
                Name = userDto.Name,
                Email = userDto.Email,
                Phonenumber = userDto.Phonenumber,
                Address = userDto.Address
            };

            var contact = await _repository.CreateContact(user);
            if (contact == null)
            {
                return BadRequest();
            }
            return Ok(user);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteContact (int id)
        {
            var names = await _repository.DeleteContact(id);
            if (!names) { 
                return NotFound();
            }
            return Ok();
        }
    }
}
